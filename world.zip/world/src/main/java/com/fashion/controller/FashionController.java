package com.fashion.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FashionController {
	@RequestMapping("/")
	public String getHome() {
		return "index";
	}
	@RequestMapping("/index")
	public String getHome1() {
		return "index";
	}
	@RequestMapping("/Form")
	public String getForm() {
		return "Form";
	}
	@RequestMapping("/Marathi")
	public String getMarathi() {
		return "Marathi";
	}
	@RequestMapping("/Punjabi")
	public String getPunjabi() {
		return "Punjabi";
	}
	@RequestMapping("/Gujrati")
	public String getGujrati() {
		return "Gujrati";
	}
	@RequestMapping("/indians")
	public String getAboutUs() {
		return "indians";
	}
	
	
}
