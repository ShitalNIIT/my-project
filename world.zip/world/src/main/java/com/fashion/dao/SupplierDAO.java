package com.fashion.dao;

import java.util.List;

import com.fashion.model.Supplier;

public interface SupplierDAO {
	public List<Supplier> list();

	public Supplier get(String id);
	

	public void saveOrUpdate(Supplier supplier);

	public String delete(String id);

}
