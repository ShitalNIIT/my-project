package com.fashion.dao;

import com.fashion.model.Users;

public interface UsersDAO {
	public void saveOrUpdate(Users user);
	public void delete(int id);


}
