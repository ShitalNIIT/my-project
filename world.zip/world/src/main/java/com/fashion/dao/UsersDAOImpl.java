package com.fashion.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fashion.model.Users;

@Repository("usersDAO")
public class UsersDAOImpl implements UsersDAO {
	@Autowired
	private SessionFactory sessionFactory;


	public UsersDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}



	@Transactional
	public void saveOrUpdate(Users user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
			
	}

	@Transactional
	public void delete(int id) {
		Users user = new Users();
		user.setId(id);
		sessionFactory.getCurrentSession().delete(user);
	}


	

}
