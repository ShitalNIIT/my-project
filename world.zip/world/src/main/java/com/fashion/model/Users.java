package com.fashion.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table
public class Users {
private int id;
private String name;
private String eId;
private String contact;
private String address;
private String pswrd;
@Id
@GeneratedValue
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String geteId() {
	return eId;
}
public void seteId(String eId) {
	this.eId = eId;
}
public String getContact() {
	return contact;
}
public void setContact(String contact) {
	this.contact = contact;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPswrd() {
	return pswrd;
}
public void setPswrd(String pswrd) {
	this.pswrd = pswrd;
}



}
