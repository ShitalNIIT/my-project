package com.fashion.service;

public class UsersService {

}
